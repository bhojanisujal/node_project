export const ADDAPI = 'ADDAPI';
export const GETAPI = 'GETAPI';

export const ALBUM_ADDAPI = 'ALBUM_ADDAPI';
export const ALBUM_GETAPI = 'ALBUM_GETAPI';

export const PROFILEADDAPI = 'PROFILEADDAPI';
export const PROFILEGETAPI = 'PROFILEGETAPI';


export const RoylitiesADDAPI = 'RoylitiesADDAPI';
export const RoylitiesGETAPI = 'RoylitiesGETAPI';

export const Pass = 'passb';
