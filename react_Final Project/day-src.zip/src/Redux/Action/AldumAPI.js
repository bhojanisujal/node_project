import axios from "axios"
import { ALBUM_ADDAPI, ALBUM_GETAPI, Pass, PROFILEGETAPI, RoylitiesGETAPI } from "../Type/Type"
import Login from "../../Pages/Login";
let token = JSON.parse(localStorage.getItem("login"))?.token;

export let auth = {
   headers: {
      "Authorization": `Bearer ${token}`
   }
}
export const AlbumAPI = () => {
   return (dispatch) => {
      axios.get('https://iris-api.mycodelibraries.com/api/Album/GetAllAlbums', auth).then((res) => {

         dispatch({ type: ALBUM_GETAPI, data: res.data.responseData });
         return res.data.responseData;

      })
   }

}
export const AddAlbumAPI = (obj) => {
   return (dispatch) => {
      axios.post('https://iris-api.mycodelibraries.com/api/Album/CreateAlbum', obj, auth).then((res) => {

         dispatch(AlbumAPI());
         return res.data.responseData;

      })
   }

}
export const EditAlbumAPI = (obj) => {
   return (dispatch) => {
      axios.post('https://iris-api.mycodelibraries.com/api/Album/UpdateAlbum', obj, auth).then((res) => {

         dispatch(AlbumAPI());
         return res.data.responseData;

      })
   }

}
export const deleteAlbumAPI = (id) => {
   return (dispatch) => {
      axios.delete('https://iris-api.mycodelibraries.com/api/Album/DeleteAlbum/' + id, auth).then((res) => {

         dispatch(AlbumAPI());
         return res.data.responseData;

      })
   }

}

export const getProfileAPI = () => {
   return (dispatch) => {
      axios.get('https://iris-api.mycodelibraries.com/api/Profile/GetAllProfile', auth).then((res) => {
              if(res.data.isSuccess){  
         console.log(res.data)
         dispatch({ type: PROFILEGETAPI, data: res.data.responseData });
         return res.data.responseData;
             }     
      })
   }
   
}
export const AddProfileAPI = (obj,setShow) => {
   return (dispatch) => {
      axios.post('https://iris-api.mycodelibraries.com/api/Profile/CreateProfile',obj, auth).then((res) => {
        if(res.data.isSuccess){
          dispatch(getProfileAPI());
         setShow(false)
         return res.data.responseData;
        }
      })
   }

}
export const eidtProfileAPI = (obj) => {
   console.log(obj)
   return (dispatch) => {
      axios.post('https://iris-api.mycodelibraries.com/api/Profile/UpdateProfile', obj, auth).then((res) => {
         console.log(res.data.responseData)
         dispatch(getProfileAPI());
         return res.data.responseData;
      })
   }

}
export const dataeleteProfileAPI = (id) => {
   return (dispatch) => {
      axios.delete('https://iris-api.mycodelibraries.com/api/Profile/DeleteProfile/' + id, auth).then((res) => {

         dispatch(getProfileAPI());


      })
   }

}

export const AddRoylitiesAPI = () => {
   return (dispatch) => {
      axios.get('https://iris-api.mycodelibraries.com/api/Roylities/GetAllInvoice', auth).then((res) => {

         dispatch({ type: RoylitiesGETAPI, data: res.data.responseData });
         return res.data.responseData;
      })
   }
}
export const changetPassword = (obj) => {
   return () => {
      axios.post('https://iris-api.mycodelibraries.com/api/User/ChangePassword',obj,auth).then((res) => {
       

         console.log(res.data.responseData)
      })
   }

}
