import axios from "axios"
import { ADDAPI, GETAPI } from "../Type/Type"

export const addapiData = (user,navigate) =>{
    return (dispatch) =>{
        axios.post('https://iris-api.mycodelibraries.com/api/User/CreateUser',user).then((res) =>{
            {
            console.log(res)
            dispatch({type:ADDAPI , data:res.data})
 navigate('/');
        }
        })
    }
}
export const getUserLogin =(obj,setuser,navigate,user)=>{
    return (dispatch) =>{
        axios.post('https://iris-api.mycodelibraries.com/api/User/LoginAuthenticate',obj).then((res)=>{
           if(res.data.isSuccess){
            console.log(res)
               localStorage.setItem('login',JSON.stringify(res.data.responseData));
               setuser(!user);
               navigate('/')
            }
            dispatch({ type: GETAPI, data: res.data })
            return res.data
        })
    }
}